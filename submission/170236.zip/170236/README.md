#CCS425 Assigment1

DEEPESH KUMAR LALL
170236

The Code is written in python3

Instruction to run 1st code:

./crc_checksum.py <input_filename>


Instruction to run 2nd code:

./hamming_code.py

